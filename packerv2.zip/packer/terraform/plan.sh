#!/bin/bash
echo "************* execute terraform init"
## execute terrafotm build and sendout to packer-build-output

terraform plan 